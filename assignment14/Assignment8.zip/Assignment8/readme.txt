Note: when using G++, use the following command:
g++ BankAccount.cpp main.cpp -o <outfile>
