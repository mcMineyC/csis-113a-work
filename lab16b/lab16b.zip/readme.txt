I tried separating it into 3 files, Stack.h, Stack.cpp and main.cpp.  Apparently C++ gets unhappy when you try to access the templated variable out side the header.
https://stackoverflow.com/questions/36039/templates-spread-across-multiple-files
